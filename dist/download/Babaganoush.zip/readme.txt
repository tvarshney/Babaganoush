﻿===================================================
Name: Babaganoush for Sitefinity
Written by: Falafel Software Inc.
Website: http://babaganoush.falafel.com
===================================================

Thank you for downloading Babaganoush for Sitefinity!

------------------------------------------
Installation:
------------------------------------------
STEP 1:
Copy the Babaganoush.*.dll from
the folder that matches your Sitefinity version
to your website bin folder.

STEP 2.
You're done!

Please go to http://babaganoush.falafel.com for documentation.

------------------------------------------
Sitefinity Training:
------------------------------------------
We offer step by step instructor-led training online and onsite to train
your team on using, configuring , optimizing and developing for Sitefinity 5+. For
classes and schedule, please visit: http://www.falafel.com/consulting/sitefinity-services

------------------------------------------
Custom Sitefinity Solutions:
------------------------------------------
We can make your Sitefinity experience perfect. 
Whether you need help installing Sitefinity for the first time, 
integrating with another system or a custom module, we can help. 
Contact us at babaganoush@falafel.com to discuss your project.


ENJOY!!